CREATE TABLE Bills(
MaHoaDon varchar(50) primary key,
MaNhanVien varchar(50),
NgayBan date,
Id varchar(50),
TongTien int),
 CONSTRAINT FK_Staffs   FOREIGN KEY (MaNhanVien) REFERENCES Staffs(MaNhanVien)
 CONSTRAINT FK_Users   FOREIGN KEY (Id) REFERENCES Users(Id)
); 
CREATE TABLE BillsDetail(
MaHoaDon varchar(50) primary key,
Id varchar(50),
SoLuong int,
DonGia int,
TongTien int),
CONSTRAINT FK_Bills   FOREIGN KEY (MaHoaDon) REFERENCES Bills(MaHoaDon)
 CONSTRAINT FK_Flowers   FOREIGN KEY (Id) REFERENCES Flowers(Id)
); 
 
